#include <linux/fs.h>
#include <linux/uaccess.h>
#include "osfs.h"

/**
 * Function: osfs_read
 * Description: Reads data from a file.
 * Inputs:
 *   - filp: The file pointer representing the file to read from.
 *   - buf: The user-space buffer to copy the data into.
 *   - len: The number of bytes to read.
 *   - ppos: The file position pointer.
 * Returns:
 *   - The number of bytes read on success.
 *   - 0 if the end of the file is reached.
 *   - -EFAULT if copying data to user space fails.
 */
static ssize_t osfs_read(struct file *filp, char __user *buf, size_t len, loff_t *ppos){
    struct inode *inode = file_inode(filp);
    struct osfs_inode *osfs_inode = inode->i_private;
    struct osfs_sb_info *sb_info = inode->i_sb->s_fs_info;

    size_t total_read = 0;
    size_t remain;
    loff_t pos = *ppos;
    int extent_idx;
    uint32_t extent_offset;
    void *datablock;

    /* EOF */
    if (pos >= osfs_inode->i_size)
        return 0;
    
    /* not exceed the file size*/
    if (pos + len > osfs_inode->i_size)
        len = osfs_inode->i_size - pos;

    remain = len;

    /* Step1: find the initial extent */
    extent_offset = pos;
    for (extent_idx = 0; extent_idx < MAX_EXTENTS; extent_idx++) {
        uint32_t extent_size =
            osfs_inode->extents[extent_idx].length * BLOCK_SIZE;

        if (extent_offset < extent_size)
            break;

        extent_offset -= extent_size;
    }

    if (extent_idx == MAX_EXTENTS)
        return 0;

    /* Step2: read the data following extent */
    while (remain > 0 && extent_idx < MAX_EXTENTS) {
        struct osfs_extent *ext = &osfs_inode->extents[extent_idx];
        size_t extent_bytes = ext->length * BLOCK_SIZE;
        size_t to_read;

        if (extent_offset >= extent_bytes)
            break;

        to_read = min(remain, extent_bytes - extent_offset);

        datablock = sb_info->data_blocks
            + ext->start_block * BLOCK_SIZE
            + extent_offset;

        if (copy_to_user(buf + total_read, datablock, to_read))
            return -EFAULT;

        total_read += to_read;
        remain -= to_read;

        extent_idx++;
        extent_offset = 0;
    }

    *ppos += total_read;

    return total_read;
}



/**
 * Function: osfs_write
 * Description: Writes data to a file.
 * Inputs:
 *   - filp: The file pointer representing the file to write to.
 *   - buf: The user-space buffer containing the data to write.
 *   - len: The number of bytes to write.
 *   - ppos: The file position pointer.
 * Returns:
 *   - The number of bytes written on success.
 *   - -EFAULT if copying data from user space fails.
 *   - Adjusted length if the write exceeds the block size.
 */
static ssize_t osfs_write(struct file *filp, const char __user *buf, size_t len, loff_t *ppos)
{   
    // Step1: Retrieve the inode and filesystem information
    struct inode *inode = file_inode(filp);
    struct osfs_inode *osfs_inode = inode->i_private;
    struct osfs_sb_info *sb_info = inode->i_sb->s_fs_info;
    ssize_t total_written = 0;

    // while loop until read all data
    while(len > 0){
        int extent_idx;
        uint32_t extent_offset = *ppos; 

        // Step2: Find the corresponding extent that contains *ppos
        for (extent_idx = 0; extent_idx < osfs_inode->extent_count; extent_idx++) {
            uint32_t extent_len = osfs_inode->extents[extent_idx].length * BLOCK_SIZE;

            if (extent_offset < extent_len)
                break; // find the correct extent
            else
                extent_offset -= extent_len; // go to next extent
        }

        // Step3: if offset exceed allocated extents，need to allocate new extent
        if (extent_idx == osfs_inode->extent_count) { 
            if (osfs_inode->extent_count >= MAX_EXTENTS) {
                pr_err("osfs_write: reached MAX_EXTENTS, cannot allocate more\n"); 
                return total_written ? total_written : -ENOSPC;
            }

            // Allocate a new extent (1 block)
            int ret = osfs_alloc_extent(sb_info, 1, &osfs_inode->extents[extent_idx]);
            if (ret) {
                pr_err("osfs_write: failed to allocate new extent\n");
                return total_written ? total_written : ret;
            }

            osfs_inode->extents[extent_idx].length = 1; 
            osfs_inode->extent_count++;               
            extent_offset = 0; 
        }

        size_t to_write = min(len, osfs_inode->extents[extent_idx].length * BLOCK_SIZE - extent_offset);

        // Step4: Write data from user space to the data block
        void *data_block = sb_info->data_blocks 
                           + osfs_inode->extents[extent_idx].start_block * BLOCK_SIZE 
                           + extent_offset;
        if (copy_from_user(data_block, buf + total_written, to_write))
            return -EFAULT;

        *ppos += to_write;
        total_written += to_write;
        len -= to_write;

        // Step5: Update inode & osfs_inode attribute
        if (*ppos > osfs_inode->i_size)
            osfs_inode->i_size = *ppos;

        uint32_t used_blocks = 0;
        for (int i = 0; i < MAX_EXTENTS; i++)
            used_blocks += osfs_inode->extents[i].length;
        osfs_inode->i_blocks = used_blocks;
        inode->i_size = osfs_inode->i_size;
    }

    osfs_inode->__i_mtime = osfs_inode->__i_ctime = current_time(inode);
    mark_inode_dirty(inode);

    // Step6: Return the number of bytes written
    return total_written;
}



/**
 * Struct: osfs_file_operations
 * Description: Defines the file operations for regular files in osfs.
 */
const struct file_operations osfs_file_operations = {
    .open = generic_file_open, // Use generic open or implement osfs_open if needed
    .read = osfs_read,
    .write = osfs_write,
    .llseek = default_llseek,
    // Add other operations as needed
};

/**
 * Struct: osfs_file_inode_operations
 * Description: Defines the inode operations for regular files in osfs.
 * Note: Add additional operations such as getattr as needed.
 */
const struct inode_operations osfs_file_inode_operations = {
    // Add inode operations here, e.g., .getattr = osfs_getattr,
};
